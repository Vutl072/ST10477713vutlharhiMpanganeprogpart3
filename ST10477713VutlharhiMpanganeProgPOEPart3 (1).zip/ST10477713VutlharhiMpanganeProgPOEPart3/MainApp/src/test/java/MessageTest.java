import com.mycompany.mainapp.Message;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MessageTest {

    // ================= MESSAGE LENGTH =================

    @Test
    public void testMessageLengthSuccess() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals(
                "Message ready to send.",
                msg.checkMessageLength()
        );
    }

    @Test
    public void testMessageLengthFail() {

        String longMessage = "A".repeat(260);

        Message msg = new Message(
                1,
                "+27718693002",
                longMessage
        );

        assertTrue(
                msg.checkMessageLength()
                        .contains("Message exceeds 250 characters")
        );
    }

    // ================= RECIPIENT NUMBER =================

    @Test
    public void testRecipientSuccess() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Hello"
        );

        assertEquals(
                "Cell phone number successfully captured.",
                msg.checkRecipientCell()
        );
    }

    @Test
    public void testRecipientFail() {

        Message msg = new Message(
                1,
                "0812345678",
                "Hello"
        );

        assertEquals(
                "Cell phone number is incorrectly formatted or does not contain an international code.",
                msg.checkRecipientCell()
        );
    }

    // ================= MESSAGE HASH =================

    @Test
    public void testMessageHashCreated() {

        Message msg = new Message(
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        String hash = msg.createMessageHash();

        assertNotNull(hash);
        assertTrue(hash.contains(":0:"));
    }

    // ================= MESSAGE ID =================

    @Test
    public void testMessageIDCreated() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Hello"
        );

        assertTrue(msg.checkMessageID());
    }

    // ================= SEND MESSAGE =================

    @Test
    public void testSendMessageOption() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Hello"
        );

        assertEquals(
                "Message successfully sent.",
                msg.sentMessage(1)
        );
    }

    @Test
    public void testDisregardMessageOption() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Hello"
        );

        assertEquals(
                "Press 0 to delete message.",
                msg.sentMessage(2)
        );
    }

    @Test
    public void testStoreMessageOption() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Hello"
        );

        assertEquals(
                "Message successfully stored.",
                msg.sentMessage(3)
        );
    }
}