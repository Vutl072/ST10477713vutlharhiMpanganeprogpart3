package com.mycompany.mainapp;

import javax.swing.JOptionPane;

public class MainApp {

    public static void main(String[] args) {

        // ================= REGISTER =================

        String firstName = JOptionPane.showInputDialog("Enter First Name:");
        String lastName = JOptionPane.showInputDialog("Enter Last Name:");
        String username = JOptionPane.showInputDialog("Create Username:");
        String password = JOptionPane.showInputDialog("Create Password:");
        String cell = JOptionPane.showInputDialog("Enter Cell Number (+27...)");

        Login user = new Login(firstName, lastName, username, password, cell);

        String registrationMessage = user.registerUser();

        JOptionPane.showMessageDialog(null, registrationMessage);

        // ================= LOGIN =================

        if (registrationMessage.equals("User successfully registered.")) {

            String loginUser = JOptionPane.showInputDialog("Enter Username:");
            String loginPass = JOptionPane.showInputDialog("Enter Password:");

            boolean loginStatus = user.loginUser(loginUser, loginPass);

            JOptionPane.showMessageDialog(null,
                    user.returnLoginStatus(loginStatus));

            // ================= QUICKCHAT =================

            if (loginStatus) {

                // ⭐ PART 3 ADDITION: LOAD JSON INTO ARRAYS
                Message.loadStoredMessagesFromJSON();

                JOptionPane.showMessageDialog(null,
                        "Welcome to QuickChat.");

                int totalToSend = Integer.parseInt(
                        JOptionPane.showInputDialog(
                                "How many messages would you like to send?"
                        )
                );

                int currentMessage = 0;

                while (true) {

                    String menu = """
                                  Choose an option:

                                  1) Send Messages
                                  2) Show Recently Sent Messages
                                  3) Stored Messages
                                  4) Quit
                                  """;

                    int choice = Integer.parseInt(
                            JOptionPane.showInputDialog(menu));

                    switch (choice) {

                        // ================= SEND MESSAGE =================
                        case 1:

                            if (currentMessage >= totalToSend) {

                                JOptionPane.showMessageDialog(null,
                                        "You have reached your message limit.");
                                break;
                            }

                            String recipient = JOptionPane.showInputDialog(
                                    "Enter recipient number:");

                            String messageText = JOptionPane.showInputDialog(
                                    "Enter your message:");

                            Message message = new Message(
                                    currentMessage + 1,
                                    recipient,
                                    messageText);

                            JOptionPane.showMessageDialog(null,
                                    message.checkRecipientCell());

                            String lengthResult = message.checkMessageLength();

                            JOptionPane.showMessageDialog(null,
                                    lengthResult);

                            if (lengthResult.equals("Message ready to send.")) {

                                String sendMenu = """
                                                  Choose an option:

                                                  1) Send Message
                                                  2) Disregard Message
                                                  3) Store Message
                                                  """;

                                int sendChoice = Integer.parseInt(
                                        JOptionPane.showInputDialog(sendMenu));

                                String result = message.sentMessage(sendChoice);

                                JOptionPane.showMessageDialog(null,
                                        result);

                                if (sendChoice == 1) {

                                    JOptionPane.showMessageDialog(null,
                                            message.printMessages());

                                    currentMessage++;
                                }
                            }

                            break;

                        // ================= RECENT SENT MESSAGES =================
                        case 2:

                            if (Message.getSentMessages().isEmpty()) {

                                JOptionPane.showMessageDialog(null,
                                        "No sent messages found.");

                            } else {

                                String output = "";

                                for (Message msg : Message.getSentMessages()) {

                                    output += "Recipient: " + msg.getRecipient()
                                            + "\nMessage: " + msg.getMessage()
                                            + "\n\n";
                                }

                                JOptionPane.showMessageDialog(null, output);
                            }

                            break;

                        // ================= STORED MESSAGES (PART 3 UPGRADED) =================
                        case 3:

                            String storedMenu = """
                                                Stored Messages Menu

                                                1. Display Stored Messages
                                                2. Search By Recipient
                                                3. Search By Message Hash
                                                4. Display Longest Message
                                                5. Display Full Report
                                                6. Back
                                                """;

                            int storedChoice = Integer.parseInt(
                                    JOptionPane.showInputDialog(storedMenu));

                            switch (storedChoice) {

                                // DISPLAY STORED
                                case 1:

                                    if (Message.getStoredMessages().isEmpty()) {

                                        JOptionPane.showMessageDialog(null,
                                                "No stored messages found.");

                                    } else {

                                        String result = "";

                                        for (Message msg : Message.getStoredMessages()) {

                                            result += "Recipient: " + msg.getRecipient()
                                                    + "\nMessage: " + msg.getMessage()
                                                    + "\n\n";
                                        }

                                        JOptionPane.showMessageDialog(null, result);
                                    }

                                    break;

                                // SEARCH BY RECIPIENT
                                case 2:

                                    String searchRecipient = JOptionPane.showInputDialog(
                                            "Enter recipient number:");

                                    String found = "";

                                    for (Message msg : Message.getStoredMessages()) {

                                        if (msg.getRecipient().equals(searchRecipient)) {

                                            found += msg.getMessage() + "\n\n";
                                        }
                                    }

                                    JOptionPane.showMessageDialog(null,
                                            found.isEmpty()
                                                    ? "No messages found."
                                                    : found);

                                    break;

                                // SEARCH BY HASH
                                case 3:

                                    String searchHash = JOptionPane.showInputDialog(
                                            "Enter message hash:");

                                    String resultMsg = "";

                                    for (Message msg : Message.getStoredMessages()) {

                                        if (msg.getMessageHash().equals(searchHash)) {

                                            resultMsg = msg.getMessage();
                                            break;
                                        }
                                    }

                                    JOptionPane.showMessageDialog(null,
                                            resultMsg.isEmpty()
                                                    ? "Message not found."
                                                    : resultMsg);

                                    break;

                                // LONGEST MESSAGE
                                case 4:

                                    String longest = "";

                                    for (Message msg : Message.getStoredMessages()) {

                                        if (msg.getMessage().length() > longest.length()) {
                                            longest = msg.getMessage();
                                        }
                                    }

                                    JOptionPane.showMessageDialog(null,
                                            "Longest Message:\n\n" + longest);

                                    break;

                                // FULL REPORT
                                case 5:

                                    String report = "";

                                    for (Message msg : Message.getStoredMessages()) {

                                        report += msg.printMessages() + "\n\n";
                                    }

                                    JOptionPane.showMessageDialog(null, report);

                                    break;

                                case 6:
                                    break;

                                default:

                                    JOptionPane.showMessageDialog(null,
                                            "Invalid option.");
                            }

                            break;

                        // ================= QUIT =================
                        case 4:

                            JOptionPane.showMessageDialog(null,
                                    "Total messages sent: "
                                            + Message.returnTotalMessages());

                            JOptionPane.showMessageDialog(null,
                                    "Goodbye!");

                            System.exit(0);

                            break;

                        default:

                            JOptionPane.showMessageDialog(null,
                                    "Invalid option.");
                    }
                }
            }
        }
    }
}