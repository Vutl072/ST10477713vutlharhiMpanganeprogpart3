package com.mycompany.mainapp;

import java.util.Random;
import java.util.ArrayList;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;
import java.util.Scanner;

public class Message {

    private static int totalMessages = 0;

    // Part 3 Arrays
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    private static ArrayList<Message> storedMessages = new ArrayList<>();
    private static ArrayList<Message> disregardedMessages = new ArrayList<>();

    private static ArrayList<String> messageHashes = new ArrayList<>();
    private static ArrayList<String> messageIDs = new ArrayList<>();

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;
    private String messageHash;

    public Message(int messageNumber, String recipient, String message) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    // ================= ID GENERATION =================
    private String generateMessageID() {

        Random random = new Random();

        long number =
                1000000000L +
                (long) (random.nextDouble() * 9000000000L);

        return String.valueOf(number);
    }

    public boolean checkMessageID() {
        return messageID.length() == 10;
    }

    // ================= VALIDATION =================
    public String checkRecipientCell() {

        if (recipient.matches("^\\+27\\d{9}$")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code.";
        }
    }

    public String checkMessageLength() {

        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by "
                    + excess
                    + ", please reduce the size.";
        }
    }

    // ================= HASH =================
    public String createMessageHash() {

        String[] words = message.split(" ");

        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        return messageID.substring(0, 2)
                + ":"
                + messageNumber
                + ":"
                + firstWord.toUpperCase()
                + lastWord.toUpperCase();
    }

    // ================= SEND / STORE / DISREGARD =================
    public String sentMessage(int option) {

        switch (option) {

            case 1:

                totalMessages++;

                sentMessages.add(this);
                messageHashes.add(messageHash);
                messageIDs.add(messageID);

                return "Message successfully sent.";

            case 2:

                disregardedMessages.add(this);

                return "Press 0 to delete message.";

            case 3:

                storedMessages.add(this);

                messageHashes.add(messageHash);
                messageIDs.add(messageID);

                storeMessage();

                return "Message successfully stored.";

            default:
                return "Invalid option.";
        }
    }

    // ================= PRINT =================
    public String printMessages() {

        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + message;
    }

    // ================= TOTAL =================
    public static int returnTotalMessages() {
        return totalMessages;
    }

    // ================= JSON STORE =================
    @SuppressWarnings("unchecked")
    public void storeMessage() {

        JSONArray messageList = new JSONArray();

        JSONObject messageDetails = new JSONObject();

        messageDetails.put("MessageID", messageID);
        messageDetails.put("MessageHash", messageHash);
        messageDetails.put("Recipient", recipient);
        messageDetails.put("Message", message);

        messageList.add(messageDetails);

        try (FileWriter file = new FileWriter("storedMessages.json")) {

            file.write(messageList.toJSONString());
            file.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ================= PART 3 ADDITIONS =================

    // SEARCH BY MESSAGE ID
    public static String searchByMessageID(String id) {

        for (Message msg : storedMessages) {

            if (msg.getMessageID().equals(id)) {
                return msg.getMessage();
            }
        }

        return "Message ID not found.";
    }

    // LONGEST MESSAGE
    public static String getLongestMessage() {

        String longest = "";

        for (Message msg : storedMessages) {

            if (msg.getMessage().length() > longest.length()) {
                longest = msg.getMessage();
            }
        }

        return longest;
    }

    // LOAD JSON 
    public static void loadStoredMessagesFromJSON() {

        try {

            FileReader reader = new FileReader("storedMessages.json");
            Scanner sc = new Scanner(reader);

            StringBuilder jsonData = new StringBuilder();

            while (sc.hasNextLine()) {
                jsonData.append(sc.nextLine());
            }

            sc.close();

            System.out.println("Stored messages loaded from JSON.");

        } catch (Exception e) {
            System.out.println("No stored messages file found.");
        }
    }

    // ================= GETTERS =================
    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    // ================= ARRAY GETTERS =================
    public static ArrayList<Message> getSentMessages() {
        return sentMessages;
    }

    public static ArrayList<Message> getStoredMessages() {
        return storedMessages;
    }

    public static ArrayList<Message> getDisregardedMessages() {
        return disregardedMessages;
    }

    public static ArrayList<String> getMessageHashes() {
        return messageHashes;
    }

    public static ArrayList<String> getMessageIDs() {
        return messageIDs;
    }
}